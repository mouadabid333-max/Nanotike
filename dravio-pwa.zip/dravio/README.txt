DRAVIO as an installable app (PWA)

Files (keep them all in the SAME folder, no sub-folders):
  index.html, manifest.webmanifest, sw.js,
  icon-192.png, icon-512.png, icon-512-maskable.png, apple-touch-icon.png, favicon.png

Put the folder online with any free static host (HTTPS is required):
  - GitHub Pages: new public repository > "uploading an existing file" > select all files > Commit
    > Settings > Pages > Branch "main" / root > Save. Your link: https://YOUR-NAME.github.io/REPO-NAME/
  - Netlify Drop: open app.netlify.com/drop and drop this folder (or the zip).
  - Cloudflare Pages: Workers & Pages > Create > Pages > Upload assets.

iPhone: open the link in Safari > Share > Add to Home Screen > Add.
Android: open the link in Chrome > Install app (or menu > Add to Home screen).
After the first visit the app also opens offline. Your data (CSV, sessions) stays in the browser of that phone.
